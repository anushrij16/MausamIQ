# MausamIQ

**Team AETHERX · Smart India Hackathon 2026 · SIH26076**

> Not Just Weather. Weather That Matters to You.

MausamIQ is an Android-first personalized weather intelligence and decision-support experience. Instead of stopping at current conditions, it combines weather context, a user's persona, activity, location, and time window to explain what matters and recommend a next action.

## Current Build

The current foundation includes a premium atmospheric dark theme, branded launcher/splash assets, Android-friendly bottom navigation, a personalized Home dashboard, Forecast, AI Insights, Smart Travel, and Alerts screens. The Home experience demonstrates the core SIH story: a rain window is interpreted differently for a Student commute or a Fitness morning session. Demo content is visibly labeled and is not presented as live provider data.

## Technology

The project uses Expo SDK 54, React Native, TypeScript, Expo Router, NativeWind-compatible theme tokens, and a managed Node/Expo development setup. The interface is local-first in this phase and avoids unnecessary JSON data/config files; framework-required files remain unchanged.

## Run

Use `pnpm dev` in the managed development environment. For a local Android target, use `pnpm android` from an Expo-compatible Android emulator or device. Run `pnpm check` for TypeScript validation and `pnpm test` for the repository test suite.

## Architecture Direction

The intended production data flow is `WeatherProvider → WeatherService → NormalizedWeather → Personalization Engine → Grounded Insight UI`. Live, cached, and demo states must remain explicit. Any future AI copy must be grounded only in normalized weather factors and user context; it must not invent forecasts.

## SIH Demo Flow

Open Home, review the Student commute insight, open the explanation sheet, inspect the rainfall and activity factors, then move through Forecast and Smart Travel. Return to Home and switch the persona to Fitness to show how the same weather receives a different priority and recommendation.

## Remaining Work

Production weather integration, real authentication, onboarding, local persistence, saved locations, notification delivery, maps, multilingual support, backend APIs, and broader automated journey coverage are intentionally tracked in `todo.md` and `CONTINUATION_PROMPT.md`.
