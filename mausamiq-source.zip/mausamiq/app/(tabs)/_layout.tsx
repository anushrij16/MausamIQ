import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 10 : Math.max(insets.bottom, 8);
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: "#32D6C7", tabBarInactiveTintColor: "#7085A7", tabBarButton: HapticTab, tabBarStyle: { backgroundColor: "#0F2040", borderTopColor: "#243A63", borderTopWidth: 1, height: 62 + bottomPadding, paddingTop: 8, paddingBottom: bottomPadding }, tabBarLabelStyle: { fontSize: 10, fontWeight: "700" } }}>
    <Tabs.Screen name="index" options={{ title: "Home", tabBarIcon: ({ color }) => <IconSymbol name="house.fill" size={22} color={color} /> }} />
    <Tabs.Screen name="forecast" options={{ title: "Forecast", tabBarIcon: ({ color }) => <IconSymbol name="chart.bar.fill" size={22} color={color} /> }} />
    <Tabs.Screen name="insights" options={{ title: "Insights", tabBarIcon: ({ color }) => <IconSymbol name="sparkles" size={22} color={color} /> }} />
    <Tabs.Screen name="travel" options={{ title: "Travel", tabBarIcon: ({ color }) => <IconSymbol name="car.fill" size={22} color={color} /> }} />
    <Tabs.Screen name="alerts" options={{ title: "Alerts", tabBarIcon: ({ color }) => <IconSymbol name="bell.fill" size={22} color={color} /> }} />
  </Tabs>;
}
