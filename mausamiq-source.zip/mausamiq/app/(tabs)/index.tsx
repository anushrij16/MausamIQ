import { useMemo, useState } from "react";
import { router } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { haptic } from "@/lib/haptics";

const hourly = [
  { time: "Now", temp: "28°", icon: "wb-sunny", rain: "12%" },
  { time: "2 PM", temp: "29°", icon: "wb-sunny", rain: "18%" },
  { time: "4 PM", temp: "27°", icon: "cloud", rain: "48%" },
  { time: "6 PM", temp: "25°", icon: "grain", rain: "78%" },
  { time: "8 PM", temp: "24°", icon: "cloud", rain: "62%" },
];

const daily = [
  { day: "Today", high: "29°", low: "23°", icon: "partly-cloudy-day", rain: "78%" },
  { day: "Tue", high: "30°", low: "22°", icon: "wb-sunny", rain: "24%" },
  { day: "Wed", high: "28°", low: "22°", icon: "cloud", rain: "56%" },
  { day: "Thu", high: "27°", low: "21°", icon: "grain", rain: "71%" },
];

export default function HomeScreen() {
  const [showWhy, setShowWhy] = useState(false);
  const [persona, setPersona] = useState("Student");
  const insight = useMemo(() => persona === "Fitness"
    ? { title: "Your best outdoor window is still ahead.", detail: "Cooler air and lower rain risk make 7:00–9:00 AM your clearest movement window.", action: "Plan your morning session", color: "#32D6C7" }
    : { title: "Rain is likely during your usual commute.", detail: "Your College → Home window overlaps with the highest rainfall chance today.", action: "Carry an umbrella before leaving", color: "#8D8BFF" }, [persona]);

  return (
    <ScreenContainer containerClassName="bg-[#0B1630]" className="px-5 pt-3">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.topRow}>
          <View>
            <Text style={styles.eyebrow}>MONDAY, 25 AUGUST</Text>
            <Text style={styles.greeting}>Good morning, Arjun</Text>
            <View style={styles.locationRow}><IconSymbol name="location.fill" size={14} color="#8EA5C5" /><Text style={styles.location}>Bengaluru, Karnataka</Text><View style={styles.demoPill}><Text style={styles.demoText}>DEMO</Text></View></View>
          </View>
          <Pressable accessibilityLabel="Open profile" onPress={() => { haptic.light(); router.push("/login"); }} style={({ pressed }) => [styles.avatar, pressed && styles.pressed]}><Text style={styles.avatarText}>AS</Text></Pressable>
        </View>

        <View style={styles.heroCard}>
          <View style={styles.heroGlow} />
          <View style={styles.heroTop}><View><Text style={styles.heroLabel}>CURRENTLY</Text><Text style={styles.condition}>Partly cloudy</Text></View><Text style={styles.weatherIcon}>◒</Text></View>
          <View style={styles.tempRow}><Text style={styles.temperature}>28</Text><Text style={styles.degree}>°C</Text><View style={styles.feels}><Text style={styles.feelsLabel}>FEELS LIKE</Text><Text style={styles.feelsValue}>30°</Text></View></View>
          <View style={styles.metrics}><Metric icon="water-drop" label="Humidity" value="68%" /><Metric icon="air" label="Wind" value="12 km/h" /><Metric icon="visibility" label="Visibility" value="8.4 km" /></View>
          <View style={styles.sunLine}><Text style={styles.sunText}>☼  Sunrise 5:58 AM</Text><Text style={styles.sunText}>Sunset 6:35 PM  ◐</Text></View>
        </View>

        <SectionTitle label="WHAT MATTERS TO YOU" caption="Personalized for your activity" />
        <View style={styles.insightCard}>
          <View style={[styles.insightAccent, { backgroundColor: insight.color }]} />
          <View style={styles.insightBody}><View style={styles.insightMeta}><View style={[styles.iconBubble, { backgroundColor: insight.color + "20" }]}><IconSymbol name={(persona === "Fitness" ? "directions-run" : "commute") as any} size={20} color={insight.color} /><Text style={styles.priority}>HIGH PRIORITY</Text></View><Text style={styles.timeTag}>4–6 PM</Text></View><Text style={styles.insightTitle}>{insight.title}</Text><Text style={styles.insightDetail}>{insight.detail}</Text><Pressable accessibilityRole="button" accessibilityLabel="See why this matters" onPress={() => { haptic.light(); setShowWhy(true); }} style={({ pressed }) => [styles.whyButton, pressed && styles.pressed]}><Text style={styles.whyText}>WHY AM I SEEING THIS?</Text><IconSymbol name="chevron.right" size={16} color="#B9B8FF" /></Pressable></View>
        </View>

        <View style={styles.recommendation}><View style={styles.recIcon}><IconSymbol name="lightbulb" size={22} color="#FFC857" /></View><View style={{ flex: 1 }}><Text style={styles.recLabel}>MAUSAMIQ RECOMMENDS</Text><Text style={styles.recTitle}>{insight.action}</Text><Text style={styles.recSupport}>Based on rain probability, your commute, and your 5 PM activity window.</Text></View><IconSymbol name="chevron.right" size={18} color="#607394" /></View>

        <SectionTitle label="TODAY AT A GLANCE" caption="Hourly forecast" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hourlyRow}>{hourly.map((item, index) => <View key={item.time} style={[styles.hourCard, index === 0 && styles.hourActive]}><Text style={[styles.hourTime, index === 0 && styles.hourActiveText]}>{item.time}</Text><IconSymbol name={item.icon as any} size={24} color={index === 0 ? "#0B1630" : "#FFC857"} /><Text style={[styles.hourTemp, index === 0 && styles.hourActiveText]}>{item.temp}</Text><Text style={[styles.rain, index === 0 && styles.hourActiveText]}>◌ {item.rain}</Text></View>)}</ScrollView>

        <SectionTitle label="7-DAY FORECAST" caption="Tap to explore" />
        <View style={styles.dailyCard}>{daily.map((item, index) => <View key={item.day} style={[styles.dailyRow, index !== daily.length - 1 && styles.rowBorder]}><Text style={styles.dayText}>{item.day}</Text><IconSymbol name={item.icon as any} size={20} color="#FFC857" /><Text style={styles.rainSmall}>◌ {item.rain}</Text><Text style={styles.high}>{item.high}</Text><Text style={styles.low}>{item.low}</Text></View>)}</View>

        <SectionTitle label="SEE WEATHER DIFFERENTLY" caption="Switch persona" />
        <View style={styles.personaRow}>{["Student", "Fitness", "Farmer"].map(item => <Pressable key={item} onPress={() => { haptic.selection(); setPersona(item); }} style={[styles.personaChip, persona === item && styles.personaChipActive]}><Text style={[styles.personaText, persona === item && styles.personaTextActive]}>{item}</Text></Pressable>)}</View>

        {showWhy && <Pressable accessibilityRole="button" accessibilityLabel="Close explanation" onPress={() => setShowWhy(false)} style={styles.sheetBackdrop}><Pressable onPress={() => {}} style={styles.sheet}><View style={styles.sheetHandle} /><Text style={styles.sheetEyebrow}>EXPLAINABLE INTELLIGENCE</Text><Text style={styles.sheetTitle}>Why this matters to you</Text><Text style={styles.sheetBody}>MausamIQ connects the forecast to your context instead of showing a generic weather alert.</Text><Factor label="Rain probability" value="78% · 4–6 PM" /><Factor label="Your activity" value={persona === "Fitness" ? "Morning outdoor session" : "Evening commute"} /><Factor label="Relevant location" value={persona === "Fitness" ? "Cubbon Park" : "College → Home"} /><Pressable onPress={() => setShowWhy(false)} style={styles.sheetButton}><Text style={styles.sheetButtonText}>GOT IT</Text></Pressable></Pressable></Pressable>}
      </ScrollView>
    </ScreenContainer>
  );
}

function Metric({ icon, label, value }: { icon: any; label: string; value: string }) { return <View style={styles.metric}><IconSymbol name={icon} size={16} color="#91B6D8" /><Text style={styles.metricLabel}>{label}</Text><Text style={styles.metricValue}>{value}</Text></View>; }
function Factor({ label, value }: { label: string; value: string }) { return <View style={styles.factor}><View style={styles.factorDot} /><View><Text style={styles.factorLabel}>{label}</Text><Text style={styles.factorValue}>{value}</Text></View></View>; }
function SectionTitle({ label, caption }: { label: string; caption: string }) { return <View style={styles.sectionTitle}><Text style={styles.sectionLabel}>{label}</Text><Text style={styles.sectionCaption}>{caption}</Text></View>; }

const styles = StyleSheet.create({ content: { paddingBottom: 34 }, topRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 22 }, eyebrow: { color: "#6D84A8", fontSize: 10, letterSpacing: 1.6, fontWeight: "700" }, greeting: { color: "#F3F7FC", fontSize: 24, fontWeight: "800", marginTop: 5 }, locationRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 7 }, location: { color: "#91A5C4", fontSize: 12 }, demoPill: { backgroundColor: "#23365C", borderRadius: 5, paddingHorizontal: 6, paddingVertical: 3, marginLeft: 4 }, demoText: { color: "#5BA8FF", fontSize: 9, fontWeight: "800", letterSpacing: 1 }, avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: "#23365C", justifyContent: "center", alignItems: "center", borderWidth: 1, borderColor: "#3C547F" }, avatarText: { color: "#B9B8FF", fontWeight: "800" }, heroCard: { backgroundColor: "#14264A", borderRadius: 26, padding: 21, overflow: "hidden", marginBottom: 28, borderWidth: 1, borderColor: "#243A63" }, heroGlow: { position: "absolute", width: 180, height: 180, borderRadius: 90, backgroundColor: "#5BA8FF18", right: -50, top: -60 }, heroTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }, heroLabel: { color: "#80A4CF", fontSize: 10, fontWeight: "800", letterSpacing: 1.4 }, condition: { color: "#F4F8FC", fontSize: 16, fontWeight: "700", marginTop: 5 }, weatherIcon: { color: "#FFC857", fontSize: 45, lineHeight: 45 }, tempRow: { flexDirection: "row", alignItems: "flex-start", marginTop: 9 }, temperature: { color: "#FFFFFF", fontSize: 76, fontWeight: "800", letterSpacing: -4, lineHeight: 78 }, degree: { color: "#B8C9DF", fontSize: 26, fontWeight: "500", marginTop: 10 }, feels: { borderLeftWidth: 1, borderLeftColor: "#395174", marginLeft: 16, paddingLeft: 14, marginTop: 16 }, feelsLabel: { color: "#80A4CF", fontSize: 9, letterSpacing: 1, fontWeight: "700" }, feelsValue: { color: "#E8EFF9", fontSize: 18, fontWeight: "700", marginTop: 3 }, metrics: { flexDirection: "row", justifyContent: "space-between", marginTop: 11, paddingTop: 15, borderTopWidth: 1, borderTopColor: "#294368" }, metric: { alignItems: "center", gap: 3 }, metricLabel: { color: "#7891B2", fontSize: 9, marginTop: 2 }, metricValue: { color: "#E6EFF9", fontSize: 12, fontWeight: "700" }, sunLine: { flexDirection: "row", justifyContent: "space-between", marginTop: 17 }, sunText: { color: "#91A5C4", fontSize: 10 }, sectionTitle: { flexDirection: "row", alignItems: "baseline", justifyContent: "space-between", marginBottom: 12 }, sectionLabel: { color: "#89A2C5", fontSize: 11, letterSpacing: 1.4, fontWeight: "800" }, sectionCaption: { color: "#526B91", fontSize: 11 }, insightCard: { flexDirection: "row", backgroundColor: "#182A4E", borderRadius: 20, overflow: "hidden", marginBottom: 12, borderWidth: 1, borderColor: "#2B4168" }, insightAccent: { width: 5 }, insightBody: { padding: 16, flex: 1 }, insightMeta: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, iconBubble: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 9, paddingVertical: 6, borderRadius: 8 }, priority: { color: "#B9B8FF", fontSize: 9, fontWeight: "800", letterSpacing: 1 }, timeTag: { color: "#8EA5C5", fontSize: 11, fontWeight: "700" }, insightTitle: { color: "#F4F8FC", fontSize: 18, fontWeight: "800", lineHeight: 24, marginTop: 14 }, insightDetail: { color: "#91A5C4", fontSize: 12, lineHeight: 18, marginTop: 6 }, whyButton: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 16, paddingTop: 13, borderTopWidth: 1, borderTopColor: "#2B4168" }, whyText: { color: "#B9B8FF", fontSize: 10, fontWeight: "800", letterSpacing: 1 }, recommendation: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#182A4E", padding: 15, borderRadius: 18, marginBottom: 28, borderWidth: 1, borderColor: "#2B4168" }, recIcon: { width: 40, height: 40, borderRadius: 13, backgroundColor: "#FFC85718", justifyContent: "center", alignItems: "center" }, recLabel: { color: "#D2A83F", fontSize: 9, letterSpacing: 1.1, fontWeight: "800" }, recTitle: { color: "#F4F8FC", fontSize: 15, fontWeight: "800", marginTop: 3 }, recSupport: { color: "#7891B2", fontSize: 11, marginTop: 3, lineHeight: 16 }, hourlyRow: { gap: 10, paddingBottom: 28 }, hourCard: { width: 65, alignItems: "center", gap: 9, paddingVertical: 12, borderRadius: 16, backgroundColor: "#14264A", borderWidth: 1, borderColor: "#253B60" }, hourActive: { backgroundColor: "#32D6C7", borderColor: "#32D6C7" }, hourTime: { color: "#86A0C3", fontSize: 11, fontWeight: "700" }, hourActiveText: { color: "#0B1630" }, hourTemp: { color: "#F4F8FC", fontSize: 16, fontWeight: "800" }, rain: { color: "#7891B2", fontSize: 10 }, dailyCard: { backgroundColor: "#14264A", borderRadius: 18, paddingHorizontal: 15, marginBottom: 28, borderWidth: 1, borderColor: "#253B60" }, dailyRow: { flexDirection: "row", alignItems: "center", paddingVertical: 14, gap: 12 }, rowBorder: { borderBottomWidth: 1, borderBottomColor: "#253B60" }, dayText: { color: "#EAF2F7", fontWeight: "700", width: 55 }, rainSmall: { color: "#7891B2", fontSize: 11, flex: 1 }, high: { color: "#F4F8FC", fontWeight: "800" }, low: { color: "#7891B2", width: 30, textAlign: "right" }, personaRow: { flexDirection: "row", gap: 9, marginBottom: 10 }, personaChip: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12, backgroundColor: "#14264A", borderWidth: 1, borderColor: "#2B4168" }, personaChipActive: { backgroundColor: "#32D6C7", borderColor: "#32D6C7" }, personaText: { color: "#91A5C4", fontSize: 12, fontWeight: "700" }, personaTextActive: { color: "#0B1630" }, pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] }, sheetBackdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "#050B18CC", justifyContent: "flex-end", zIndex: 20 }, sheet: { backgroundColor: "#16294D", padding: 24, borderTopLeftRadius: 28, borderTopRightRadius: 28, borderWidth: 1, borderColor: "#385277" }, sheetHandle: { width: 38, height: 4, borderRadius: 2, backgroundColor: "#527098", alignSelf: "center", marginBottom: 22 }, sheetEyebrow: { color: "#B9B8FF", fontSize: 10, letterSpacing: 1.4, fontWeight: "800" }, sheetTitle: { color: "#F4F8FC", fontSize: 25, fontWeight: "800", marginTop: 7 }, sheetBody: { color: "#9DB0CA", fontSize: 13, lineHeight: 19, marginTop: 10, marginBottom: 18 }, factor: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 10, borderTopWidth: 1, borderTopColor: "#2B4168" }, factorDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#32D6C7" }, factorLabel: { color: "#7891B2", fontSize: 11 }, factorValue: { color: "#F4F8FC", fontSize: 14, fontWeight: "700", marginTop: 3 }, sheetButton: { backgroundColor: "#32D6C7", borderRadius: 14, paddingVertical: 15, alignItems: "center", marginTop: 15 }, sheetButtonText: { color: "#0B1630", fontSize: 12, fontWeight: "900", letterSpacing: 1.4 } });
