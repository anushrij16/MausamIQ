/** @type {const} */
const themeColors = {
  primary: { light: '#16B8AD', dark: '#32D6C7' },
  background: { light: '#EAF2F7', dark: '#0B1630' },
  surface: { light: '#FFFFFF', dark: '#14264A' },
  foreground: { light: '#0B1630', dark: '#F4F8FC' },
  muted: { light: '#60738F', dark: '#91A5C4' },
  border: { light: '#D6E1EA', dark: '#2B4168' },
  success: { light: '#12998F', dark: '#32D6C7' },
  warning: { light: '#C88B1C', dark: '#FFC857' },
  error: { light: '#D45A5A', dark: '#FF7A7A' },
};
module.exports = { themeColors };
