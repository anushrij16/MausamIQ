import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { geocodePlace, getRoute, getWeather } from "./integrations/weather";

const COOKIE_NAME = "app_session_id";
const coordinatesSchema = z.object({ latitude: z.number().finite().min(-90).max(90), longitude: z.number().finite().min(-180).max(180), label: z.string().min(2).max(180) });

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  weather: router({
    search: publicProcedure.input(z.object({ query: z.string().trim().min(2).max(120) })).query(({ input }) => geocodePlace(input.query)),
    forecast: publicProcedure.input(coordinatesSchema).query(({ input }) => getWeather(input)),
    route: publicProcedure.input(z.object({ from: coordinatesSchema, to: coordinatesSchema })).query(({ input }) => getRoute(input.from, input.to)),
  }),
});

export type AppRouter = typeof appRouter;
