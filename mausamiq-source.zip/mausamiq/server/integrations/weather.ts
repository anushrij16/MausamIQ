export type DataState = "live" | "demo" | "cached";

export type Coordinates = { latitude: number; longitude: number; label: string };

export type NormalizedWeather = {
  state: DataState;
  updatedAt: string;
  location: Coordinates;
  current: { temperature: number; feelsLike: number; humidity: number; windSpeed: number; visibility: number | null; weatherCode: number };
  hourly: Array<{ time: string; temperature: number; rainProbability: number; weatherCode: number }>;
  daily: Array<{ date: string; high: number; low: number; rainProbability: number; weatherCode: number }>;
};

export type GeocodedPlace = Coordinates & { country?: string; admin1?: string };
export type RouteResult = { state: DataState; from: GeocodedPlace; to: GeocodedPlace; distanceKm: number; durationMinutes: number; geometry: Array<[number, number]> };

const weatherApi = "https://api.open-meteo.com/v1/forecast";
const geocodeApi = "https://geocoding-api.open-meteo.com/v1/search";
const routeApi = "https://router.project-osrm.org/route/v1/driving";

async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`Provider request failed with ${response.status}`);
  return response.json() as Promise<T>;
}

export async function geocodePlace(query: string): Promise<GeocodedPlace[]> {
  const name = query.trim();
  if (name.length < 2) return [];
  const params = new URLSearchParams({ name, count: "5", language: "en", format: "json" });
  const result = await getJson<{ results?: Array<{ name: string; latitude: number; longitude: number; country?: string; admin1?: string }> }>(`${geocodeApi}?${params}`);
  return (result.results ?? []).map((place) => ({ latitude: place.latitude, longitude: place.longitude, label: [place.name, place.admin1, place.country].filter(Boolean).join(", "), country: place.country, admin1: place.admin1 }));
}

export async function getWeather(location: Coordinates): Promise<NormalizedWeather> {
  const params = new URLSearchParams({ latitude: String(location.latitude), longitude: String(location.longitude), timezone: "auto", forecast_days: "7", current: "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m", hourly: "temperature_2m,precipitation_probability,weather_code", daily: "temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code" });
  const result = await getJson<{ current: any; hourly: any; daily: any }>(`${weatherApi}?${params}`);
  const hourly = (result.hourly?.time ?? []).slice(0, 12).map((time: string, index: number) => ({ time, temperature: result.hourly.temperature_2m[index], rainProbability: result.hourly.precipitation_probability[index], weatherCode: result.hourly.weather_code[index] }));
  const daily = (result.daily?.time ?? []).map((date: string, index: number) => ({ date, high: result.daily.temperature_2m_max[index], low: result.daily.temperature_2m_min[index], rainProbability: result.daily.precipitation_probability_max[index], weatherCode: result.daily.weather_code[index] }));
  return { state: "live", updatedAt: new Date().toISOString(), location, current: { temperature: result.current.temperature_2m, feelsLike: result.current.apparent_temperature, humidity: result.current.relative_humidity_2m, windSpeed: result.current.wind_speed_10m, visibility: null, weatherCode: result.current.weather_code }, hourly, daily };
}

export async function getRoute(from: GeocodedPlace, to: GeocodedPlace): Promise<RouteResult> {
  const coords = `${from.longitude},${from.latitude};${to.longitude},${to.latitude}`;
  const params = new URLSearchParams({ overview: "full", geometries: "geojson", alternatives: "false" });
  const result = await getJson<{ code: string; routes?: Array<{ distance: number; duration: number; geometry?: { coordinates: Array<[number, number]> } }> }>(`${routeApi}/${coords}?${params}`);
  const route = result.routes?.[0];
  if (result.code !== "Ok" || !route) throw new Error("No route found between these locations");
  return { state: "live", from, to, distanceKm: route.distance / 1000, durationMinutes: Math.round(route.duration / 60), geometry: route.geometry?.coordinates ?? [] };
}
