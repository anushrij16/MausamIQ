# MausamIQ Mobile Interface Design

## Product Direction

MausamIQ is an Android-first personalized weather intelligence experience for Team AETHERX and SIH26076. The interface should feel like a calm, premium decision layer over weather data: atmospheric but highly readable, futuristic without becoming noisy, and optimized for portrait orientation and one-handed use.

The primary demo story is: **same weather, different person, different intelligence**. The interface therefore prioritizes a concise explanation of what matters, why it matters, and what the user should do next.

## Screen List

| Screen | Primary content and functionality |
|---|---|
| Splash | Branded MausamIQ mark, concise tagline, short transition into the experience. |
| Landing | Value proposition, premium weather atmosphere, sample insight, Get Started and Explore actions. |
| Login | Email, password, remember session, forgot password, register path. Demo entry remains available for judges. |
| Register | Full name, email, password, confirm password, terms acceptance, validation feedback. |
| Onboarding: Location | Manual location selection first, optional current-location permission with a clear privacy explanation. |
| Onboarding: Persona | Student, Farmer, Traveller, Fitness, Outdoor Worker, and General persona cards. |
| Onboarding: Interests | Select relevant weather concerns such as rain, heat, wind, visibility, and alerts. |
| Onboarding: Activities | Add a primary activity and time window such as commute, workout, farm work, or travel. |
| Onboarding: Saved Locations | Add Home, College, Work, or Other locations without continuous tracking. |
| Onboarding: Notifications | Configure important alert categories with an accessible toggle treatment. |
| Onboarding: Language | Choose English first, with the architecture ready for Indian-language expansion. |
| Home | Personalized greeting, current weather hero, What Matters to You insight, grounded recommendation, hourly forecast, 7-day forecast, metrics, and smart alerts. |
| Forecast | Larger hourly and daily forecast views with clear stale/cached state labels. |
| AI Insights | Persona-aware insights with supporting factors and a Why am I seeing this? explanation sheet. |
| Smart Travel | From/to/date/departure controls, route-weather context, and a decision summary. |
| Alerts | Relevant weather alerts, empty state when no alerts exist, and notification preference shortcut. |
| Map | Saved locations and travel endpoints, with a graceful unavailable state if map services are not configured. |
| Profile | Persona, saved locations, activities, and a quick switch for demo scenarios. |
| Settings | Theme, demo mode, notifications, privacy, language, and cached-data information. |
| Privacy | Plain-language explanation of location use, data minimization, and manual-location alternatives. |
| Why This Matters sheet | Bottom sheet that explicitly lists weather factor, time window, activity, and relevance reason. |

## Core User Flows

### Demo Flow

1. Launch into the branded splash and landing experience.
2. Tap Get Started and choose Demo Mode.
3. Choose the Student persona and preview College plus Home locations.
4. Land on Home with an evening commute insight.
5. Tap Why am I seeing this? to inspect the rainfall, commute window, and relevant activity factors.
6. Open Smart Travel to review a College-to-Home journey summary.
7. Switch persona to Fitness and observe the insight priority change without changing the underlying weather scenario.

### Personalization Flow

1. Select a persona.
2. Select weather interests.
3. Add an activity and time window.
4. Add saved locations manually or allow one-time current-location access.
5. Review the personalized dashboard.
6. Use the explanation sheet to understand every recommendation.

### Failure and Offline Flow

1. If refresh fails, retain the last cached weather result.
2. Show the exact last-updated time and a visible cached label.
3. Provide a retry action and keep navigation usable.
4. If location permission is denied, continue with manual location selection.
5. If AI is unavailable, show deterministic grounded fallback copy based only on normalized weather inputs.

## Layout and Interaction Rules

The app uses portrait 9:16 layouts with a comfortable 16–20dp horizontal gutter and generous bottom safe-area spacing. The most important action stays in the lower half of the screen where it can be reached with one hand. Cards use medium-to-large corner radii, restrained shadows, and layered surfaces rather than full-screen glass effects.

Primary actions use filled buttons with strong contrast, subtle pressed scaling, and light haptic feedback on Android. Secondary actions use outlined or tonal buttons. All icon-only actions include accessible labels. Lists use performant list primitives and avoid placing important content under the bottom navigation bar.

## Brand Colors

| Token | Color | Purpose |
|---|---|---|
| Ink Navy | `#0B1630` | Primary dark background and high-contrast text. |
| Midnight Blue | `#14264A` | Elevated surfaces and hero card depth. |
| Monsoon Teal | `#32D6C7` | Brand accent, active controls, and positive weather windows. |
| Electric Sky | `#5BA8FF` | Forecast accents and interactive links. |
| Sun Gold | `#FFC857` | Warm highlights, sunrise, and attention states. |
| Cloud Mist | `#EAF2F7` | Light-mode background and soft surfaces. |
| Rain Violet | `#8D8BFF` | Insight identity and AI explanation accents. |
| Alert Coral | `#FF7A7A` | Severe-weather and important-alert emphasis. |

Light mode uses Cloud Mist as the base, white surfaces, Ink Navy typography, and Monsoon Teal for actions. Dark mode uses Ink Navy as the base, Midnight Blue surfaces, Cloud Mist typography, and the same accent colors with sufficient contrast.

## Typography

Use a strong display style for the current temperature and page titles, with compact semibold labels for metadata and readable body copy for explanations. Numeric weather values should be visually dominant but never be the only way information is communicated; pair them with labels and icons.

## Architecture Vocabulary

The UI should consume normalized weather data through a weather service abstraction. Persona-aware prioritization belongs in a personalization layer, while natural-language copy should be generated only from grounded factors. Demo data must be explicitly separated from live or cached data in state and presentation.
